package ru.rewardwheel;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

public class RewardWheelPlugin extends JavaPlugin implements Listener, CommandExecutor {

    private HttpClient httpClient;
    private String backendUrl;
    private String apiKey;
    private long pollIntervalTicks;
    private int httpTimeoutSeconds;
    private int taskId = -1;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadConfigValues();

        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(httpTimeoutSeconds))
                .build();

        getServer().getPluginManager().registerEvents(this, this);
        var cmd = getCommand("rewardwheel");
        if (cmd != null) cmd.setExecutor(this);

        if (isMisconfigured()) {
            getLogger().warning("RewardWheel не настроен: заполните backend-url и api-key в plugins/RewardWheel/config.yml, затем выполните /rewardwheel reload");
        } else {
            startPolling();
            getLogger().info("RewardWheel включён, опрос бэкенда каждые " + (pollIntervalTicks / 20) + " сек.");
        }
    }

    @Override
    public void onDisable() {
        stopPolling();
    }

    private void loadConfigValues() {
        reloadConfig();
        this.backendUrl = getConfig().getString("backend-url", "").replaceAll("/+$", "");
        this.apiKey = getConfig().getString("api-key", "");
        int seconds = getConfig().getInt("poll-interval-seconds", 5);
        this.pollIntervalTicks = Math.max(20L, seconds * 20L);
        this.httpTimeoutSeconds = Math.max(2, getConfig().getInt("http-timeout-seconds", 8));
    }

    private boolean isMisconfigured() {
        return backendUrl.isBlank() || apiKey.isBlank() || apiKey.equals("PASTE_API_KEY_HERE");
    }

    private void startPolling() {
        stopPolling();
        taskId = getServer().getScheduler().runTaskTimerAsynchronously(this, this::pollOnce, 40L, pollIntervalTicks).getTaskId();
    }

    private void stopPolling() {
        if (taskId != -1) {
            getServer().getScheduler().cancelTask(taskId);
            taskId = -1;
        }
    }

    /** Runs on an async thread. Fetches pending rewards and, for players who are online, delivers them. */
    private void pollOnce() {
        if (isMisconfigured()) return;
        try {
            JsonObject body = httpGetJson("/api/plugin/pending-rewards");
            if (body == null) return;
            JsonArray rewards = body.getAsJsonArray("rewards");
            if (rewards == null || rewards.isEmpty()) return;

            List<String> deliveredIds = new ArrayList<>();
            List<Runnable> mainThreadCommands = new ArrayList<>();

            for (JsonElement el : rewards) {
                JsonObject reward = el.getAsJsonObject();
                String id = reward.get("id").getAsString();
                String nick = reward.get("minecraftNick").getAsString();
                String command = reward.has("command") && !reward.get("command").isJsonNull()
                        ? reward.get("command").getAsString() : "";

                var player = Bukkit.getPlayerExact(nick);
                if (player == null || !player.isOnline()) continue; // will retry next poll / on join

                deliveredIds.add(id);
                if (!command.isBlank()) {
                    mainThreadCommands.add(() -> {
                        try {
                            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
                        } catch (Exception e) {
                            getLogger().log(Level.WARNING, "Не удалось выполнить команду награды: " + command, e);
                        }
                    });
                }
            }

            if (!mainThreadCommands.isEmpty()) {
                getServer().getScheduler().runTask(this, () -> mainThreadCommands.forEach(Runnable::run));
            }
            if (!deliveredIds.isEmpty()) {
                ackRewards(deliveredIds);
            }
        } catch (Exception e) {
            getLogger().log(Level.WARNING, "Ошибка опроса RewardWheel backend", e);
        }
    }

    private JsonObject httpGetJson(String path) throws IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(backendUrl + path + "?key=" + apiKey))
                .timeout(Duration.ofSeconds(httpTimeoutSeconds))
                .GET()
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            getLogger().warning("RewardWheel backend вернул код " + response.statusCode() + ": " + response.body());
            return null;
        }
        return JsonParser.parseString(response.body()).getAsJsonObject();
    }

    private void ackRewards(List<String> ids) {
        try {
            JsonArray arr = new JsonArray();
            ids.forEach(arr::add);
            JsonObject payload = new JsonObject();
            payload.add("ids", arr);

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(backendUrl + "/api/plugin/ack?key=" + apiKey))
                    .timeout(Duration.ofSeconds(httpTimeoutSeconds))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(payload.toString()))
                    .build();
            httpClient.send(request, HttpResponse.BodyHandlers.discarding());
        } catch (Exception e) {
            getLogger().log(Level.WARNING, "Не удалось подтвердить выдачу наград", e);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        // Deliver any rewards waiting for this player shortly after they log in.
        getServer().getScheduler().runTaskLaterAsynchronously(this, this::pollOnce, 60L);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage("§7[RewardWheel] §fИспользование: /rw reload | check | testgive <ник> <команда>");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "reload" -> {
                loadConfigValues();
                if (!isMisconfigured()) startPolling(); else stopPolling();
                sender.sendMessage("§a[RewardWheel] Конфиг перезагружен.");
            }
            case "check" -> {
                sender.sendMessage("§a[RewardWheel] Проверяю награды...");
                getServer().getScheduler().runTaskAsynchronously(this, this::pollOnce);
            }
            case "testgive" -> {
                if (args.length < 3) {
                    sender.sendMessage("§cИспользование: /rw testgive <ник> <команда...>");
                    return true;
                }
                String player = args[1];
                String cmd = String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length))
                        .replace("{player}", player);
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
                sender.sendMessage("§a[RewardWheel] Выполнено: " + cmd);
            }
            default -> sender.sendMessage("§cНеизвестная подкоманда.");
        }
        return true;
    }
}
