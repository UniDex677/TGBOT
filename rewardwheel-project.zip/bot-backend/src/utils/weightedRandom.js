/**
 * Choose an index from `items` proportionally to each item's `weight` field.
 * Returns -1 if the list is empty or all weights are 0.
 */
function pickWeightedIndex(items) {
  const total = items.reduce((sum, it) => sum + Math.max(0, Number(it.weight) || 0), 0);
  if (total <= 0) return -1;
  let roll = Math.random() * total;
  for (let i = 0; i < items.length; i++) {
    roll -= Math.max(0, Number(items[i].weight) || 0);
    if (roll <= 0) return i;
  }
  return items.length - 1;
}

module.exports = { pickWeightedIndex };
