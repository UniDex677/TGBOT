const { nanoid } = require('nanoid');
const { getData, save } = require('../db');

const SESSION_TTL_MS = 12 * 60 * 60 * 1000; // 12 hours

function createSession() {
  const db = getData();
  const token = nanoid(40);
  db.adminSessions.push({ token, expiresAt: Date.now() + SESSION_TTL_MS });
  // keep the list tidy
  db.adminSessions = db.adminSessions.filter((s) => s.expiresAt > Date.now());
  save();
  return token;
}

function isValidSession(token) {
  if (!token) return false;
  const db = getData();
  const session = db.adminSessions.find((s) => s.token === token);
  if (!session) return false;
  if (session.expiresAt < Date.now()) return false;
  return true;
}

function requireAdmin(req, res, next) {
  const token = req.headers['x-admin-token'];
  if (!isValidSession(token)) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  next();
}

module.exports = { createSession, isValidSession, requireAdmin };
