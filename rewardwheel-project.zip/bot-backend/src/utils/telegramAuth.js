const crypto = require('crypto');

/**
 * Validates the `initData` string sent by a Telegram Mini App, per Telegram docs:
 * https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
 *
 * Returns the parsed user object if valid, or null if invalid/expired.
 */
function validateInitData(initData, botToken, maxAgeSeconds = 86400) {
  if (!initData || !botToken) return null;

  const params = new URLSearchParams(initData);
  const hash = params.get('hash');
  if (!hash) return null;
  params.delete('hash');

  const pairs = [];
  for (const [key, value] of params.entries()) {
    pairs.push(`${key}=${value}`);
  }
  pairs.sort();
  const dataCheckString = pairs.join('\n');

  const secretKey = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
  const computedHash = crypto.createHmac('sha256', secretKey).update(dataCheckString).digest('hex');

  if (computedHash !== hash) return null;

  const authDate = Number(params.get('auth_date') || 0);
  if (maxAgeSeconds > 0 && Date.now() / 1000 - authDate > maxAgeSeconds) return null;

  let user = null;
  try {
    user = JSON.parse(params.get('user') || 'null');
  } catch (e) {
    return null;
  }
  if (!user || !user.id) return null;
  return user;
}

/**
 * DEV FALLBACK ONLY: allows testing the Mini App outside of Telegram by passing
 * ?debug_user_id=12345 — automatically disabled unless ALLOW_DEBUG_AUTH=1 in env.
 */
function debugUserFromQuery(req) {
  if (process.env.ALLOW_DEBUG_AUTH !== '1') return null;
  const id = req.query.debug_user_id;
  if (!id) return null;
  return { id: Number(id), username: `debug_${id}`, first_name: 'Debug' };
}

module.exports = { validateInitData, debugUserFromQuery };
