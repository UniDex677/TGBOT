const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const { nanoid } = require('nanoid');

const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

function defaultData() {
  return {
    settings: {
      spinIntervalHours: Number(process.env.DEFAULT_SPIN_INTERVAL_HOURS || 24),
      adminPasswordHash: bcrypt.hashSync(process.env.ADMIN_PASSWORD || 'admin', 8),
      pluginApiKey: nanoid(32),
      webappUrl: process.env.WEBAPP_URL || ''
    },
    prizes: [
      { id: nanoid(8), name: '8 алмазов', icon: '💎', color: '#4dabf7', weight: 20, command: 'give {player} diamond 8' },
      { id: nanoid(8), name: '500 монет', icon: '🪙', color: '#ffd43b', weight: 30, command: 'eco give {player} 500' },
      { id: nanoid(8), name: 'Ничего', icon: '💨', color: '#868e96', weight: 25, command: '' },
      { id: nanoid(8), name: 'Алмазная кирка', icon: '⛏️', color: '#74c0fc', weight: 10, command: 'give {player} diamond_pickaxe 1' },
      { id: nanoid(8), name: '1000 монет', icon: '💰', color: '#f59f00', weight: 10, command: 'eco give {player} 1000' },
      { id: nanoid(8), name: 'Слиток нетерита', icon: '🔥', color: '#e8590c', weight: 5, command: 'give {player} netherite_ingot 1' }
    ],
    users: {},
    pendingRewards: [],
    spinHistory: [],
    adminSessions: []
  };
}

let cache = null;

function ensureLoaded() {
  if (cache) return cache;
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) {
    cache = defaultData();
    save();
  } else {
    try {
      cache = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    } catch (e) {
      console.error('Не удалось прочитать db.json, создаю новую базу:', e.message);
      cache = defaultData();
      save();
    }
  }
  return cache;
}

function save() {
  fs.writeFileSync(DB_FILE, JSON.stringify(cache, null, 2), 'utf8');
}

function getData() {
  return ensureLoaded();
}

module.exports = { getData, save };
