const { Telegraf, Markup } = require('telegraf');
const { getData } = require('./db');

function createBot() {
  const bot = new Telegraf(process.env.BOT_TOKEN);

  bot.start((ctx) => {
    const db = getData();
    const webappUrl = db.settings.webappUrl || process.env.WEBAPP_URL;
    if (!webappUrl || !webappUrl.startsWith('https://')) {
      return ctx.reply(
        '⚠️ WEBAPP_URL ещё не настроен (нужен HTTPS-адрес). Задайте его в .env или в админ-панели.'
      );
    }
    return ctx.reply(
      'Привет! 🎡 Здесь можно раз в некоторое время бесплатно крутить колесо фортуны и получать награды на сервере.',
      Markup.inlineKeyboard([
        Markup.button.webApp('🎡 Крутить колесо', `${webappUrl}/webapp`)
      ])
    );
  });

  bot.command('admin', (ctx) => {
    const db = getData();
    const webappUrl = db.settings.webappUrl || process.env.WEBAPP_URL;
    if (!webappUrl) return ctx.reply('WEBAPP_URL не настроен.');
    ctx.reply(`Панель администратора: ${webappUrl}/admin`);
  });

  bot.catch((err) => {
    console.error('Ошибка в боте:', err);
  });

  return bot;
}

module.exports = { createBot };
