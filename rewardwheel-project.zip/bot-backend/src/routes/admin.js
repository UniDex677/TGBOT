const express = require('express');
const bcrypt = require('bcryptjs');
const { nanoid } = require('nanoid');
const { getData, save } = require('../db');
const { createSession, requireAdmin } = require('../utils/adminAuth');

const router = express.Router();

// POST /api/admin/login
router.post('/login', (req, res) => {
  const { password } = req.body;
  const db = getData();
  if (!password || !bcrypt.compareSync(String(password), db.settings.adminPasswordHash)) {
    return res.status(401).json({ error: 'wrong_password' });
  }
  const token = createSession();
  res.json({ token });
});

router.use(requireAdmin);

// GET /api/admin/overview — settings + stats for dashboard
router.get('/overview', (req, res) => {
  const db = getData();
  res.json({
    settings: {
      spinIntervalHours: db.settings.spinIntervalHours,
      webappUrl: db.settings.webappUrl,
      pluginApiKey: db.settings.pluginApiKey
    },
    stats: {
      totalUsers: Object.keys(db.users).length,
      linkedUsers: Object.values(db.users).filter((u) => u.minecraftNick).length,
      totalSpins: db.spinHistory.length,
      pendingRewards: db.pendingRewards.filter((r) => !r.delivered).length
    }
  });
});

// ---- Prizes CRUD ----
router.get('/prizes', (req, res) => {
  res.json({ prizes: getData().prizes });
});

router.post('/prizes', (req, res) => {
  const { name, icon, color, weight, command } = req.body;
  if (!name) return res.status(400).json({ error: 'name_required' });
  const db = getData();
  const prize = {
    id: nanoid(8),
    name: String(name),
    icon: String(icon || '🎁'),
    color: String(color || '#845ef7'),
    weight: Math.max(0, Number(weight) || 0),
    command: String(command || '')
  };
  db.prizes.push(prize);
  save();
  res.json({ ok: true, prize });
});

router.put('/prizes/:id', (req, res) => {
  const db = getData();
  const prize = db.prizes.find((p) => p.id === req.params.id);
  if (!prize) return res.status(404).json({ error: 'not_found' });
  const { name, icon, color, weight, command } = req.body;
  if (name !== undefined) prize.name = String(name);
  if (icon !== undefined) prize.icon = String(icon);
  if (color !== undefined) prize.color = String(color);
  if (weight !== undefined) prize.weight = Math.max(0, Number(weight) || 0);
  if (command !== undefined) prize.command = String(command);
  save();
  res.json({ ok: true, prize });
});

router.delete('/prizes/:id', (req, res) => {
  const db = getData();
  const before = db.prizes.length;
  db.prizes = db.prizes.filter((p) => p.id !== req.params.id);
  save();
  res.json({ ok: true, deleted: before - db.prizes.length });
});

// ---- Settings ----
router.post('/settings', (req, res) => {
  const { spinIntervalHours, webappUrl } = req.body;
  const db = getData();
  if (spinIntervalHours !== undefined) {
    db.settings.spinIntervalHours = Math.max(0.01, Number(spinIntervalHours) || 24);
  }
  if (webappUrl !== undefined) {
    db.settings.webappUrl = String(webappUrl);
  }
  save();
  res.json({ ok: true, settings: db.settings });
});

router.post('/settings/password', (req, res) => {
  const { newPassword } = req.body;
  if (!newPassword || String(newPassword).length < 4) {
    return res.status(400).json({ error: 'password_too_short' });
  }
  const db = getData();
  db.settings.adminPasswordHash = bcrypt.hashSync(String(newPassword), 8);
  save();
  res.json({ ok: true });
});

router.post('/settings/regenerate-key', (req, res) => {
  const db = getData();
  db.settings.pluginApiKey = nanoid(32);
  save();
  res.json({ ok: true, pluginApiKey: db.settings.pluginApiKey });
});

// ---- Users & history ----
router.get('/users', (req, res) => {
  const db = getData();
  res.json({ users: Object.values(db.users).sort((a, b) => b.createdAt - a.createdAt) });
});

router.get('/history', (req, res) => {
  const db = getData();
  res.json({ history: db.spinHistory.slice(0, 200) });
});

router.get('/pending-rewards', (req, res) => {
  const db = getData();
  res.json({ pendingRewards: db.pendingRewards.slice(-200).reverse() });
});

module.exports = router;
