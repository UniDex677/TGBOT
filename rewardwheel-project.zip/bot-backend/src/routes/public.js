const express = require('express');
const { nanoid } = require('nanoid');
const { getData, save } = require('../db');
const { pickWeightedIndex } = require('../utils/weightedRandom');
const { validateInitData, debugUserFromQuery } = require('../utils/telegramAuth');

const router = express.Router();

function authenticate(req, res, next) {
  const initData = req.body?.initData || req.query.initData;
  const user = validateInitData(initData, process.env.BOT_TOKEN) || debugUserFromQuery(req);
  if (!user) return res.status(401).json({ error: 'invalid_telegram_auth' });
  req.tgUser = user;
  next();
}

function getOrCreateUser(db, tgUser) {
  const id = String(tgUser.id);
  if (!db.users[id]) {
    db.users[id] = {
      telegramId: id,
      username: tgUser.username || '',
      firstName: tgUser.first_name || '',
      minecraftNick: '',
      lastSpin: 0,
      createdAt: Date.now()
    };
  }
  return db.users[id];
}

// GET /api/prizes — public wheel config (no secrets)
router.get('/prizes', (req, res) => {
  const db = getData();
  const prizes = db.prizes.map((p) => ({ id: p.id, name: p.name, icon: p.icon, color: p.color, weight: p.weight }));
  res.json({ prizes, spinIntervalHours: db.settings.spinIntervalHours });
});

// POST /api/me — returns current user state (linked nick, cooldown)
router.post('/me', authenticate, (req, res) => {
  const db = getData();
  const user = getOrCreateUser(db, req.tgUser);
  save();
  const cooldownMs = db.settings.spinIntervalHours * 3600 * 1000;
  const nextSpinAt = user.lastSpin ? user.lastSpin + cooldownMs : 0;
  res.json({
    minecraftNick: user.minecraftNick,
    canSpin: Date.now() >= nextSpinAt,
    nextSpinAt
  });
});

// POST /api/link — save the player's Minecraft nickname
router.post('/link', authenticate, (req, res) => {
  const nick = String(req.body.minecraftNick || '').trim();
  if (!/^[A-Za-z0-9_]{3,16}$/.test(nick)) {
    return res.status(400).json({ error: 'invalid_nickname' });
  }
  const db = getData();
  const user = getOrCreateUser(db, req.tgUser);
  user.minecraftNick = nick;
  save();
  res.json({ ok: true, minecraftNick: nick });
});

// POST /api/spin — perform a spin, return which prize index won
router.post('/spin', authenticate, (req, res) => {
  const db = getData();
  const user = getOrCreateUser(db, req.tgUser);

  if (!user.minecraftNick) {
    return res.status(400).json({ error: 'not_linked' });
  }

  const cooldownMs = db.settings.spinIntervalHours * 3600 * 1000;
  const nextSpinAt = user.lastSpin ? user.lastSpin + cooldownMs : 0;
  if (Date.now() < nextSpinAt) {
    return res.status(429).json({ error: 'cooldown', nextSpinAt });
  }

  const idx = pickWeightedIndex(db.prizes);
  if (idx === -1) return res.status(500).json({ error: 'no_prizes_configured' });
  const prize = db.prizes[idx];

  user.lastSpin = Date.now();

  const historyEntry = {
    id: nanoid(10),
    telegramId: user.telegramId,
    username: user.username,
    minecraftNick: user.minecraftNick,
    prizeId: prize.id,
    prizeName: prize.name,
    at: Date.now()
  };
  db.spinHistory.unshift(historyEntry);
  db.spinHistory = db.spinHistory.slice(0, 500); // keep last 500

  if (prize.command && prize.command.trim()) {
    db.pendingRewards.push({
      id: nanoid(10),
      telegramId: user.telegramId,
      minecraftNick: user.minecraftNick,
      command: prize.command.replace(/\{player\}/g, user.minecraftNick),
      createdAt: Date.now(),
      delivered: false
    });
  }

  save();

  res.json({
    ok: true,
    winningIndex: idx,
    prize: { id: prize.id, name: prize.name, icon: prize.icon },
    nextSpinAt: user.lastSpin + cooldownMs
  });
});

module.exports = router;
