const express = require('express');
const { getData, save } = require('../db');

const router = express.Router();

function checkApiKey(req, res, next) {
  const db = getData();
  const key = req.query.key || req.headers['x-api-key'];
  if (!key || key !== db.settings.pluginApiKey) {
    return res.status(401).json({ error: 'invalid_api_key' });
  }
  next();
}

router.use(checkApiKey);

// GET /api/plugin/pending-rewards — list of not-yet-delivered rewards
router.get('/pending-rewards', (req, res) => {
  const db = getData();
  const pending = db.pendingRewards
    .filter((r) => !r.delivered)
    .map((r) => ({ id: r.id, minecraftNick: r.minecraftNick, command: r.command }));
  res.json({ rewards: pending });
});

// POST /api/plugin/ack — mark one or more rewards as delivered
// body: { ids: ["id1", "id2"] }
router.post('/ack', (req, res) => {
  const ids = Array.isArray(req.body.ids) ? req.body.ids : [];
  const db = getData();
  let count = 0;
  for (const reward of db.pendingRewards) {
    if (ids.includes(reward.id) && !reward.delivered) {
      reward.delivered = true;
      reward.deliveredAt = Date.now();
      count++;
    }
  }
  save();
  res.json({ ok: true, acknowledged: count });
});

module.exports = router;
