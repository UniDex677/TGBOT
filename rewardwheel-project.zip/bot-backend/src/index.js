require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');

const { createBot } = require('./bot');
const publicRoutes = require('./routes/public');
const adminRoutes = require('./routes/admin');
const pluginRoutes = require('./routes/plugin');

if (!process.env.BOT_TOKEN) {
  console.error('Ошибка: BOT_TOKEN не задан в .env');
  process.exit(1);
}

const app = express();
app.use(cors());
app.use(express.json());

app.use('/webapp', express.static(path.join(__dirname, '..', 'webapp')));
app.use('/admin', express.static(path.join(__dirname, '..', 'admin')));

app.use('/api', publicRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/plugin', pluginRoutes);

app.get('/', (req, res) => res.redirect('/webapp'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ Сервер запущен: http://localhost:${PORT}`);
  console.log(`   Mini App:  /webapp`);
  console.log(`   Админка:   /admin`);
});

const bot = createBot();
bot.launch().then(() => console.log('✅ Telegram-бот запущен (polling)'));

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
