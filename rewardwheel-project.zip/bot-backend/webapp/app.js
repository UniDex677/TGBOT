(() => {
  const tg = window.Telegram?.WebApp;
  if (tg) {
    tg.ready();
    tg.expand();
    tg.setHeaderColor?.('#0b0a17');
    tg.setBackgroundColor?.('#0b0a17');
  }

  const initData = tg?.initData || '';
  // For local testing outside Telegram (?debug_user_id=1), the backend allows this
  // only when ALLOW_DEBUG_AUTH=1 is set on the server.
  const debugUserId = new URLSearchParams(location.search).get('debug_user_id');

  const canvas = document.getElementById('wheel');
  const ctx = canvas.getContext('2d');
  const spinBtn = document.getElementById('spinBtn');
  const hubLabel = document.getElementById('hubLabel');
  const cooldownHint = document.getElementById('cooldownHint');
  const nickBadge = document.getElementById('nickBadge');
  const linkPanel = document.getElementById('linkPanel');
  const nickInput = document.getElementById('nickInput');
  const linkBtn = document.getElementById('linkBtn');
  const linkError = document.getElementById('linkError');
  const modal = document.getElementById('resultModal');
  const modalIcon = document.getElementById('modalIcon');
  const modalTitle = document.getElementById('modalTitle');
  const modalDesc = document.getElementById('modalDesc');
  const modalClose = document.getElementById('modalClose');

  let prizes = [];
  let totalRotation = 0;
  let nextSpinAt = 0;
  let cooldownTimer = null;
  let isLinked = false;

  function apiUrl(path) {
    return path; // same origin
  }

  async function apiPost(path, body) {
    const payload = { ...body };
    if (initData) payload.initData = initData;
    else if (debugUserId) payload.initData = ''; // backend reads debug_user_id from query
    const url = debugUserId ? `${path}?debug_user_id=${debugUserId}` : path;
    const res = await fetch(apiUrl(url), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw Object.assign(new Error(data.error || 'request_failed'), { status: res.status, data });
    return data;
  }

  function drawWheel() {
    const n = prizes.length;
    const size = canvas.width;
    const cx = size / 2, cy = size / 2, r = size / 2 - 6;
    ctx.clearRect(0, 0, size, size);

    if (n === 0) return;
    const seg = (Math.PI * 2) / n;

    for (let i = 0; i < n; i++) {
      const start = -Math.PI / 2 + i * seg;
      const end = start + seg;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, r, start, end);
      ctx.closePath();
      ctx.fillStyle = prizes[i].color || '#845ef7';
      ctx.fill();
      ctx.strokeStyle = 'rgba(11,10,23,0.85)';
      ctx.lineWidth = 3;
      ctx.stroke();

      // label
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(start + seg / 2);
      ctx.textAlign = 'right';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#0b0a17';
      ctx.font = `${Math.max(16, size * 0.045)}px Manrope, sans-serif`;
      ctx.fillText(`${prizes[i].icon || ''} ${prizes[i].name}`, r - 18, 0);
      ctx.restore();
    }

    // hub ring
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.lineWidth = 6;
    ctx.strokeStyle = '#f5c34c';
    ctx.stroke();
  }

  function fmtRemaining(ms) {
    const totalSec = Math.max(0, Math.floor(ms / 1000));
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }

  function updateSpinAvailability() {
    const now = Date.now();
    const canSpin = isLinked && now >= nextSpinAt;

    clearInterval(cooldownTimer);
    if (!isLinked) {
      cooldownHint.textContent = 'Сначала привяжите ник, чтобы крутить колесо';
      hubLabel.textContent = 'КРУТИТЬ';
      spinBtn.disabled = true;
      return;
    }

    if (canSpin) {
      cooldownHint.textContent = 'Колесо готово — крутите!';
      hubLabel.textContent = 'КРУТИТЬ';
      spinBtn.disabled = false;
    } else {
      spinBtn.disabled = true;
      hubLabel.textContent = 'ЖДИТЕ';
      cooldownTimer = setInterval(() => {
        const left = nextSpinAt - Date.now();
        if (left <= 0) {
          clearInterval(cooldownTimer);
          updateSpinAvailability();
          return;
        }
        cooldownHint.textContent = `Следующая прокрутка через ${fmtRemaining(left)}`;
      }, 1000);
      cooldownHint.textContent = `Следующая прокрутка через ${fmtRemaining(nextSpinAt - now)}`;
    }
  }

  async function loadPrizes() {
    const res = await fetch(apiUrl('/api/prizes'));
    const data = await res.json();
    prizes = data.prizes || [];
    drawWheel();
  }

  async function loadMe() {
    const data = await apiPost('/api/me', {});
    isLinked = !!data.minecraftNick;
    nextSpinAt = data.nextSpinAt || 0;
    if (isLinked) {
      nickBadge.textContent = data.minecraftNick;
      linkPanel.style.display = 'none';
    } else {
      nickBadge.textContent = 'не привязан';
      linkPanel.style.display = 'block';
    }
    updateSpinAvailability();
  }

  linkBtn.addEventListener('click', async () => {
    linkError.textContent = '';
    const nick = nickInput.value.trim();
    if (!/^[A-Za-z0-9_]{3,16}$/.test(nick)) {
      linkError.textContent = 'Ник: 3–16 символов, латиница/цифры/подчёркивание';
      return;
    }
    linkBtn.disabled = true;
    try {
      await apiPost('/api/link', { minecraftNick: nick });
      await loadMe();
    } catch (e) {
      linkError.textContent = 'Не удалось привязать ник, попробуйте ещё раз';
    } finally {
      linkBtn.disabled = false;
    }
  });

  function spinTo(index) {
    const n = prizes.length;
    const seg = 360 / n;
    const targetAngle = (((-(index + 0.5) * seg) % 360) + 360) % 360;
    const extraSpins = 5 * 360;
    const base = Math.ceil((totalRotation + 1) / 360) * 360;
    totalRotation = base + extraSpins + targetAngle;
    canvas.style.transform = `rotate(${totalRotation}deg)`;
  }

  function showResult(prize) {
    modalIcon.textContent = prize.icon || '🎁';
    modalTitle.textContent = 'Поздравляем!';
    modalDesc.textContent = prize.name + (prize.name === 'Ничего' ? ' — в этот раз не повезло' : ' — награда придёт на сервер, когда вы зайдёте');
    modal.classList.add('open');
  }

  modalClose.addEventListener('click', () => modal.classList.remove('open'));

  spinBtn.addEventListener('click', async () => {
    if (spinBtn.disabled) return;
    spinBtn.disabled = true;
    hubLabel.textContent = '…';
    try {
      const data = await apiPost('/api/spin', {});
      spinTo(data.winningIndex);
      setTimeout(() => {
        showResult(data.prize);
        nextSpinAt = data.nextSpinAt;
        updateSpinAvailability();
        tg?.HapticFeedback?.notificationOccurred?.('success');
      }, 4700);
    } catch (e) {
      if (e.status === 429 && e.data?.nextSpinAt) {
        nextSpinAt = e.data.nextSpinAt;
        updateSpinAvailability();
      } else if (e.status === 400 && e.data?.error === 'not_linked') {
        linkPanel.style.display = 'block';
        updateSpinAvailability();
      } else {
        cooldownHint.textContent = 'Ошибка, попробуйте ещё раз';
        spinBtn.disabled = false;
        hubLabel.textContent = 'КРУТИТЬ';
      }
    }
  });

  (async function init() {
    await loadPrizes();
    await loadMe();
  })();
})();
