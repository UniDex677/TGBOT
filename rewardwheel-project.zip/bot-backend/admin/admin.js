(() => {
  let token = localStorage.getItem('rw_admin_token') || '';

  const loginScreen = document.getElementById('loginScreen');
  const app = document.getElementById('app');

  async function api(path, options = {}) {
    const res = await fetch(path, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        'x-admin-token': token,
        ...(options.headers || {})
      }
    });
    if (res.status === 401) {
      token = '';
      localStorage.removeItem('rw_admin_token');
      showLogin();
      throw new Error('unauthorized');
    }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw Object.assign(new Error(data.error || 'request_failed'), { data });
    return data;
  }

  function showLogin() {
    loginScreen.style.display = 'flex';
    app.style.display = 'none';
  }
  function showApp() {
    loginScreen.style.display = 'none';
    app.style.display = 'flex';
    refreshAll();
  }

  document.getElementById('loginBtn').addEventListener('click', async () => {
    const password = document.getElementById('loginPassword').value;
    const errEl = document.getElementById('loginError');
    errEl.textContent = '';
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      token = data.token;
      localStorage.setItem('rw_admin_token', token);
      showApp();
    } catch (e) {
      errEl.textContent = 'Неверный пароль';
    }
  });

  // ---- Tabs ----
  document.querySelectorAll('.navBtn').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.navBtn').forEach((b) => b.classList.remove('active'));
      document.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(`tab-${btn.dataset.tab}`).classList.add('active');
    });
  });

  // ---- Overview ----
  async function loadOverview() {
    const { settings, stats } = await api('/api/admin/overview');
    document.getElementById('statUsers').textContent = stats.totalUsers;
    document.getElementById('statLinked').textContent = stats.linkedUsers;
    document.getElementById('statSpins').textContent = stats.totalSpins;
    document.getElementById('statPending').textContent = stats.pendingRewards;

    document.getElementById('intervalInput').value = settings.spinIntervalHours;
    document.getElementById('webappUrlInput').value = settings.webappUrl || '';
    document.getElementById('pluginKeyBox').textContent = settings.pluginApiKey;
  }

  // ---- Prizes ----
  let editingPrizeId = null;

  async function loadPrizes() {
    const { prizes } = await api('/api/admin/prizes');
    const body = document.getElementById('prizesBody');
    body.innerHTML = '';
    prizes.forEach((p) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td style="font-size:20px">${p.icon}</td>
        <td>${escapeHtml(p.name)}</td>
        <td><span class="swatch" style="background:${p.color}"></span></td>
        <td>${p.weight}</td>
        <td><code style="font-size:12px">${escapeHtml(p.command || '—')}</code></td>
        <td>
          <button class="btn btn--outline editBtn" style="margin-right:6px">✎</button>
          <button class="btn btn--danger delBtn">✕</button>
        </td>`;
      tr.querySelector('.editBtn').addEventListener('click', () => openPrizeModal(p));
      tr.querySelector('.delBtn').addEventListener('click', () => deletePrize(p.id));
      body.appendChild(tr);
    });
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function openPrizeModal(prize) {
    editingPrizeId = prize ? prize.id : null;
    document.getElementById('prizeModalTitle').textContent = prize ? 'Изменить приз' : 'Новый приз';
    document.getElementById('pf_name').value = prize?.name || '';
    document.getElementById('pf_icon').value = prize?.icon || '🎁';
    document.getElementById('pf_color').value = prize?.color || '#845ef7';
    document.getElementById('pf_weight').value = prize?.weight ?? 10;
    document.getElementById('pf_command').value = prize?.command || '';
    document.getElementById('prizeModal').classList.add('open');
  }

  document.getElementById('addPrizeBtn').addEventListener('click', () => openPrizeModal(null));
  document.getElementById('prizeModalCancel').addEventListener('click', () => {
    document.getElementById('prizeModal').classList.remove('open');
  });

  document.getElementById('prizeModalSave').addEventListener('click', async () => {
    const payload = {
      name: document.getElementById('pf_name').value.trim(),
      icon: document.getElementById('pf_icon').value.trim(),
      color: document.getElementById('pf_color').value,
      weight: Number(document.getElementById('pf_weight').value),
      command: document.getElementById('pf_command').value.trim()
    };
    if (!payload.name) return alert('Укажите название приза');

    if (editingPrizeId) {
      await api(`/api/admin/prizes/${editingPrizeId}`, { method: 'PUT', body: JSON.stringify(payload) });
    } else {
      await api('/api/admin/prizes', { method: 'POST', body: JSON.stringify(payload) });
    }
    document.getElementById('prizeModal').classList.remove('open');
    loadPrizes();
  });

  async function deletePrize(id) {
    if (!confirm('Удалить этот приз?')) return;
    await api(`/api/admin/prizes/${id}`, { method: 'DELETE' });
    loadPrizes();
  }

  // ---- Users ----
  async function loadUsers() {
    const { users } = await api('/api/admin/users');
    const body = document.getElementById('usersBody');
    body.innerHTML = users.map((u) => `
      <tr>
        <td>@${escapeHtml(u.username || u.telegramId)}</td>
        <td>${escapeHtml(u.minecraftNick || '—')}</td>
        <td>${u.lastSpin ? new Date(u.lastSpin).toLocaleString('ru-RU') : '—'}</td>
      </tr>`).join('');
  }

  // ---- History ----
  async function loadHistory() {
    const { history } = await api('/api/admin/history');
    const body = document.getElementById('historyBody');
    body.innerHTML = history.map((h) => `
      <tr>
        <td>${new Date(h.at).toLocaleString('ru-RU')}</td>
        <td>@${escapeHtml(h.username || h.telegramId)}</td>
        <td>${escapeHtml(h.minecraftNick)}</td>
        <td>${escapeHtml(h.prizeName)}</td>
      </tr>`).join('');
  }

  // ---- Settings ----
  document.getElementById('saveIntervalBtn').addEventListener('click', async () => {
    const spinIntervalHours = Number(document.getElementById('intervalInput').value);
    await api('/api/admin/settings', { method: 'POST', body: JSON.stringify({ spinIntervalHours }) });
    alert('Сохранено');
  });

  document.getElementById('saveWebappUrlBtn').addEventListener('click', async () => {
    const webappUrl = document.getElementById('webappUrlInput').value.trim();
    await api('/api/admin/settings', { method: 'POST', body: JSON.stringify({ webappUrl }) });
    alert('Сохранено');
  });

  document.getElementById('regenKeyBtn').addEventListener('click', async () => {
    if (!confirm('Старый ключ перестанет работать — обновите его в config.yml плагина. Продолжить?')) return;
    const { pluginApiKey } = await api('/api/admin/settings/regenerate-key', { method: 'POST' });
    document.getElementById('pluginKeyBox').textContent = pluginApiKey;
  });

  document.getElementById('savePasswordBtn').addEventListener('click', async () => {
    const newPassword = document.getElementById('newPasswordInput').value;
    const msgEl = document.getElementById('passwordMsg');
    try {
      await api('/api/admin/settings/password', { method: 'POST', body: JSON.stringify({ newPassword }) });
      msgEl.style.color = '#6ff3a3';
      msgEl.textContent = 'Пароль изменён';
      document.getElementById('newPasswordInput').value = '';
    } catch (e) {
      msgEl.style.color = '#ff7a59';
      msgEl.textContent = 'Ошибка: ' + (e.data?.error || 'не удалось сохранить');
    }
  });

  function refreshAll() {
    loadOverview();
    loadPrizes();
    loadUsers();
    loadHistory();
  }

  if (token) showApp(); else showLogin();
})();
